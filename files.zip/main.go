package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"

	"github.com/gorilla/mux"
)

func main() {
	r := mux.NewRouter()

	// Health check endpoint
	r.HandleFunc("/health", healthCheck).Methods("GET")

	// Billing endpoints
	r.HandleFunc("/api/v1/billing/cpu/{instance_id}", getCPUBilling).Methods("GET")
	r.HandleFunc("/api/v1/billing/resources/{instance_id}", getResourceBilling).Methods("GET")
	r.HandleFunc("/api/v1/billing/report/{instance_id}", getBillingReport).Methods("GET")

	// Server configuration
	port := ":8080"
	log.Printf("Starting billing API server on port %s", port)
	log.Fatal(http.ListenAndServe(port, r))
}

func healthCheck(w http.ResponseWriter, r *http.Request) {
	response := map[string]string{
		"status": "healthy",
		"time":   time.Now().Format(time.RFC3339),
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func getCPUBilling(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	instanceID := vars["instance_id"]

	// Get query parameters
	startDate := r.URL.Query().Get("start_date")
	endDate := r.URL.Query().Get("end_date")

	// Default to last month if not provided
	if startDate == "" || endDate == "" {
		now := time.Now()
		firstDay := time.Date(now.Year(), now.Month()-1, 1, 0, 0, 0, 0, time.UTC)
		lastDay := time.Date(now.Year(), now.Month(), 0, 23, 59, 59, 0, time.UTC)
		startDate = firstDay.Format("2006-01-02T15:04:05")
		endDate = lastDay.Format("2006-01-02T15:04:05")
	}

	config := GnocchiConfig{
		BaseURL:  getEnv("GNOCCHI_URL", "https://your-vhi-endpoint:8041/v1"),
		Token:    getEnv("GNOCCHI_TOKEN", ""),
		Insecure: true,
	}

	client := NewGnocchiClient(config)

	// Get instance resource
	instance, err := client.GetInstanceResource(instanceID)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to get instance: %v", err), http.StatusInternalServerError)
		return
	}

	// Get CPU metric ID
	cpuMetricID, ok := instance.Metrics["cpu"]
	if !ok {
		http.Error(w, "CPU metric not found for instance", http.StatusNotFound)
		return
	}

	// Get CPU measures
	measures, err := client.GetMetricMeasures(cpuMetricID, startDate, endDate, 3600) // 1 hour granularity
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to get CPU measures: %v", err), http.StatusInternalServerError)
		return
	}

	// Calculate CPU usage
	numVCPUs := 2 // Default, should get from flavor
	if vcpuMetricID, ok := instance.Metrics["vcpus"]; ok {
		vcpuMeasures, _ := client.GetMetricMeasures(vcpuMetricID, startDate, endDate, 3600)
		if len(vcpuMeasures) > 0 {
			numVCPUs = int(vcpuMeasures[0].Value)
		}
	}

	usage := CalculateCPUUsage(measures, numVCPUs)
	billing := CalculateCPUBilling(usage, startDate, endDate)

	response := CPUBillingResponse{
		InstanceID:   instanceID,
		InstanceName: instance.DisplayName,
		StartDate:    startDate,
		EndDate:      endDate,
		VCPUs:        numVCPUs,
		Usage:        usage,
		Billing:      billing,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func getResourceBilling(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	instanceID := vars["instance_id"]

	startDate := r.URL.Query().Get("start_date")
	endDate := r.URL.Query().Get("end_date")

	if startDate == "" || endDate == "" {
		now := time.Now()
		firstDay := time.Date(now.Year(), now.Month()-1, 1, 0, 0, 0, 0, time.UTC)
		lastDay := time.Date(now.Year(), now.Month(), 0, 23, 59, 59, 0, time.UTC)
		startDate = firstDay.Format("2006-01-02T15:04:05")
		endDate = lastDay.Format("2006-01-02T15:04:05")
	}

	config := GnocchiConfig{
		BaseURL:  getEnv("GNOCCHI_URL", "https://your-vhi-endpoint:8041/v1"),
		Token:    getEnv("GNOCCHI_TOKEN", ""),
		Insecure: true,
	}

	client := NewGnocchiClient(config)

	// Get instance resource
	instance, err := client.GetInstanceResource(instanceID)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to get instance: %v", err), http.StatusInternalServerError)
		return
	}

	// Get all resource metrics
	resourceUsage := ResourceUsage{
		InstanceID:   instanceID,
		InstanceName: instance.DisplayName,
		StartDate:    startDate,
		EndDate:      endDate,
		FlavorName:   instance.FlavorName,
	}

	// CPU
	if cpuMetricID, ok := instance.Metrics["cpu"]; ok {
		measures, _ := client.GetMetricMeasures(cpuMetricID, startDate, endDate, 3600)
		numVCPUs := 2
		if vcpuMetricID, ok := instance.Metrics["vcpus"]; ok {
			vcpuMeasures, _ := client.GetMetricMeasures(vcpuMetricID, startDate, endDate, 3600)
			if len(vcpuMeasures) > 0 {
				numVCPUs = int(vcpuMeasures[0].Value)
			}
		}
		cpuUsage := CalculateCPUUsage(measures, numVCPUs)
		resourceUsage.CPU = cpuUsage
		resourceUsage.VCPUs = numVCPUs
	}

	// Memory
	if memUsageMetricID, ok := instance.Metrics["memory.usage"]; ok {
		memMeasures, _ := client.GetMetricMeasures(memUsageMetricID, startDate, endDate, 3600)
		if memTotalMetricID, ok := instance.Metrics["memory"]; ok {
			memTotalMeasures, _ := client.GetMetricMeasures(memTotalMetricID, startDate, endDate, 3600)
			if len(memTotalMeasures) > 0 {
				memUsage := CalculateMemoryUsage(memMeasures, memTotalMeasures)
				resourceUsage.Memory = memUsage
			}
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resourceUsage)
}

func getBillingReport(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	instanceID := vars["instance_id"]

	startDate := r.URL.Query().Get("start_date")
	endDate := r.URL.Query().Get("end_date")
	
	// Pricing from query params or use default
	cpuPricePerHour := parseFloat(r.URL.Query().Get("cpu_price_per_hour"), 0.05)
	memoryPricePerGB := parseFloat(r.URL.Query().Get("memory_price_per_gb"), 0.01)

	if startDate == "" || endDate == "" {
		now := time.Now()
		firstDay := time.Date(now.Year(), now.Month()-1, 1, 0, 0, 0, 0, time.UTC)
		lastDay := time.Date(now.Year(), now.Month(), 0, 23, 59, 59, 0, time.UTC)
		startDate = firstDay.Format("2006-01-02T15:04:05")
		endDate = lastDay.Format("2006-01-02T15:04:05")
	}

	config := GnocchiConfig{
		BaseURL:  getEnv("GNOCCHI_URL", "https://your-vhi-endpoint:8041/v1"),
		Token:    getEnv("GNOCCHI_TOKEN", ""),
		Insecure: true,
	}

	client := NewGnocchiClient(config)
	instance, err := client.GetInstanceResource(instanceID)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to get instance: %v", err), http.StatusInternalServerError)
		return
	}

	report := BillingReport{
		InstanceID:      instanceID,
		InstanceName:    instance.DisplayName,
		FlavorName:      instance.FlavorName,
		StartDate:       startDate,
		EndDate:         endDate,
		GeneratedAt:     time.Now().Format(time.RFC3339),
		Currency:        "USD",
		CPUPricePerHour: cpuPricePerHour,
		MemoryPricePerGB: memoryPricePerGB,
	}

	// Calculate CPU billing
	if cpuMetricID, ok := instance.Metrics["cpu"]; ok {
		measures, _ := client.GetMetricMeasures(cpuMetricID, startDate, endDate, 3600)
		numVCPUs := 2
		if vcpuMetricID, ok := instance.Metrics["vcpus"]; ok {
			vcpuMeasures, _ := client.GetMetricMeasures(vcpuMetricID, startDate, endDate, 3600)
			if len(vcpuMeasures) > 0 {
				numVCPUs = int(vcpuMeasures[0].Value)
			}
		}
		cpuUsage := CalculateCPUUsage(measures, numVCPUs)
		cpuBilling := CalculateCPUBilling(cpuUsage, startDate, endDate)
		
		report.CPUUsage = cpuUsage
		report.VCPUs = numVCPUs
		report.CPUCost = cpuBilling.TotalCPUHours * cpuPricePerHour
	}

	// Calculate Memory billing
	if memUsageMetricID, ok := instance.Metrics["memory.usage"]; ok {
		memMeasures, _ := client.GetMetricMeasures(memUsageMetricID, startDate, endDate, 3600)
		if memTotalMetricID, ok := instance.Metrics["memory"]; ok {
			memTotalMeasures, _ := client.GetMetricMeasures(memTotalMetricID, startDate, endDate, 3600)
			if len(memTotalMeasures) > 0 {
				memUsage := CalculateMemoryUsage(memMeasures, memTotalMeasures)
				report.MemoryUsage = memUsage
				
				// Calculate memory cost based on GB-hours
				totalMemoryGB := memUsage.AverageUsedMB / 1024.0
				start, _ := time.Parse("2006-01-02T15:04:05", startDate)
				end, _ := time.Parse("2006-01-02T15:04:05", endDate)
				totalHours := end.Sub(start).Hours()
				report.MemoryCost = totalMemoryGB * totalHours * memoryPricePerGB
			}
		}
	}

	report.TotalCost = report.CPUCost + report.MemoryCost

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(report)
}
