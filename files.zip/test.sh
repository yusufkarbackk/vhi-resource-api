#!/bin/bash

# Test script untuk VHI Billing API

BASE_URL="http://localhost:8080"
INSTANCE_ID="c921ed74-48e5-4fa6-b093-22d08bdda660"

echo "========================================="
echo "VHI Billing API Test Script"
echo "========================================="

# Test 1: Health Check
echo -e "\n1. Testing Health Check..."
curl -s "${BASE_URL}/health" | jq '.'

# Test 2: Get CPU Billing (default last month)
echo -e "\n2. Testing CPU Billing (last month)..."
curl -s "${BASE_URL}/api/v1/billing/cpu/${INSTANCE_ID}" | jq '.'

# Test 3: Get CPU Billing (custom date range)
echo -e "\n3. Testing CPU Billing (custom date: January 2026)..."
curl -s "${BASE_URL}/api/v1/billing/cpu/${INSTANCE_ID}?start_date=2026-01-01T00:00:00&end_date=2026-01-31T23:59:59" | jq '.'

# Test 4: Get Resource Billing (CPU + Memory)
echo -e "\n4. Testing Resource Billing (CPU + Memory)..."
curl -s "${BASE_URL}/api/v1/billing/resources/${INSTANCE_ID}" | jq '.'

# Test 5: Get Billing Report with custom pricing
echo -e "\n5. Testing Billing Report (custom pricing)..."
curl -s "${BASE_URL}/api/v1/billing/report/${INSTANCE_ID}?cpu_price_per_hour=0.08&memory_price_per_gb=0.015" | jq '.'

# Test 6: Get only summary from Billing Report
echo -e "\n6. Testing Billing Report Summary..."
curl -s "${BASE_URL}/api/v1/billing/report/${INSTANCE_ID}" | jq '{
  instance_name,
  flavor_name,
  start_date,
  end_date,
  cpu_cost,
  memory_cost,
  total_cost,
  currency
}'

echo -e "\n========================================="
echo "Tests completed!"
echo "========================================="
